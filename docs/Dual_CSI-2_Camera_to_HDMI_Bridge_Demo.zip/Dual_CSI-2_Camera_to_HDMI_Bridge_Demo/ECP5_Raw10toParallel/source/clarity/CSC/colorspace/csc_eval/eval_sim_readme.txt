=========== CSC Testbench ===========


=== Normal sequence of operation: 

   1)  Asynchronous reset is asserted for few cycles 
   2)  The input "inpvalid" is asserted, indicating valid input data is 
       present. 
   3)  After latency of few cycles output "outvalid" goes high, indicating valid output
       data is present.
