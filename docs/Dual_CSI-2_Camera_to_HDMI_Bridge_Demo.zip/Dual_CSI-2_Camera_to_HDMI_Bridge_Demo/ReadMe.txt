Dual CSI-2 Camera to HDMI Bridge Demo

To enusre proper operation of the demonstration, both ECP5 and Crosslink design should be
updated on the Embedded Vision Development Kit.  The attached designs are not gauranteed
to work with previous versions of the demonstration. 